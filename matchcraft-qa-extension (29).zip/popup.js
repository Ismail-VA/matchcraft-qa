// MatchCraft QA Extension — popup.js v7
const S = { accounts:[], active:null, baseUrl:null, tabId:null, activeView:'dashboard', activeTab:'overview', sessionInfo:null };
const ENG = {11:'Google Search',18:'Bing Search',2:'Display',4:'Remarketing',7:'Social Express',12:'Facebook',14:'Yelp',15:'PMax',16:'Display Programmatic',1:'Google Display'};

// ─── INIT ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadAccounts(); detectPlatform(); bindAll();
});

function bindAll() {
  bi('nav-dashboard', () => showView('dashboard'));
  bi('nav-qa',        () => showView('qa'));
  bi('nav-data',      () => showView('data'));
  bi('nav-raw',       () => showView('raw'));
  bi('btn-showadd',   () => toggleAdd());
  bi('btn-addgo',     () => submitAdd());
  bi('btn-addcancel', () => toggleAdd(false));
  bi('btn-export',    () => toggleExportMenu());
  bi('btn-csv',       () => { closeExportMenu(); exportCSV(); });
  bi('btn-gsheet',    () => { closeExportMenu(); exportGSheet(); });
  bi('btn-pdf',       () => { closeExportMenu(); exportPDF(); });
  bi('btn-json',      () => { closeExportMenu(); exportJSON(); });
  bi('btn-pull',      () => rePull());
  document.addEventListener('click', e => { if(!ge('export-wrap').contains(e.target)) closeExportMenu(); });
  ge('add-id').addEventListener('keydown',   e => { if(e.key==='Enter') submitAdd(); });
  ge('add-label').addEventListener('keydown', e => { if(e.key==='Enter') submitAdd(); });
  ['overview','budget','segments','keywords','ads','extensions','analytics','callt','geo','adgroups','tickets'].forEach(t => {
    const el = ge('tab-'+t); if(el) el.addEventListener('click', () => showTab(t));
  });
}
const ge = id => document.getElementById(id);
const bi = (id, fn) => { const el=ge(id); if(el) el.addEventListener('click', fn); };

// ─── PLATFORM ─────────────────────────────────────────────────────────────────
function detectPlatform() {
  chrome.tabs.query({}, tabs => {
    const tab = tabs.find(t=>t.active&&t.url&&t.url.includes('advertiserreports.com')) ||
                tabs.find(t=>t.url&&t.url.includes('advertiserreports.com'));
    if (!tab) { ge('inst-name').textContent='🔴 No platform tab'; return; }
    S.baseUrl = new URL(tab.url).origin;
    S.tabId = tab.id;
    ge('inst-label').textContent = new URL(tab.url).hostname.split('.')[0];
    ge('inst-name').textContent = '🟢 ' + S.baseUrl;
    ge('inst-hint').textContent = 'Initialising...';
    chrome.tabs.sendMessage(S.tabId, {type:'GET_PAGE_CONTEXT'}, r => {
      if(r && r.merchantId) ge('add-id').value = r.merchantId;
    });
    initSession();
  });
}

async function initSession() {
  const tries = [
    {url:'/rip/common/json/getSessionState', post:true},
    {url:'/rip/json/getSessionState',        post:false},
    {url:'/rip/manage/json/getSessionState', post:true},
  ];
  for (const t of tries) {
    try {
      const r = await bg(S.baseUrl+t.url, t.post ? {} : null);
      if (!r||!r.ok) continue;
      const d=r.data, res=d&&d.result;
      const cp = t.url.replace('/getSessionState','');
      const mp = cp.includes('/rip/common/json') ? '/rip/manage/json' : (cp.includes('/rip/json') ? '/rip/manage/json' : cp);
      S.sessionInfo = {
        post: t.post, commonPath: cp, managePath: mp,
        clientId: res&&(res.clientId||res.currentClientId)||null,
        loginName: res&&(res.loginName||res.currentLoginName||res.email)||'',
        version: res&&(res.buildDate||res.version)||new Date().toISOString().slice(0,10),
      };
      ge('inst-hint').textContent = 'Ready ('+(t.post?'POST':'GET')+ ' mode)';
      return;
    } catch(e) {}
  }
  ge('inst-hint').textContent = 'Session error';
}

// ─── API ──────────────────────────────────────────────────────────────────────
function bg(url, postBody) {
  return new Promise((res, rej) => {
    chrome.runtime.sendMessage({type:'API_FETCH', url, postBody}, r => {
      if(chrome.runtime.lastError) { rej(new Error(chrome.runtime.lastError.message)); return; }
      res(r);
    });
  });
}

function mkBody(id) {
  const {clientId,loginName,version} = S.sessionInfo;
  return {currentClientId:clientId, currentLoginName:loginName, data:{id:String(id)}, version};
}

const EP_PATHS = {
  'getSessionState':                              '/rip/common/json',
  'getUserPreferences':                           '/rip/common/json',
  'getEngineBidAdjustmentFactors':               '/rip/setup/json',
  'getAccountMerchants':                         '/rip/setup/json',
  'getConnectAccount':                           '/rip/manage/json',
  'getConnectOrderKeywordsPerformance':          '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderAdsPerformance':               '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderDisplayAdsPerformance':        '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderAdGroupsPerformance':          '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectSegments':                          '/rip/manageAdvertiserPerformanceOptimization/json',
  // Connect content endpoints
  'getConnectOrderAds':                          '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderKeywords':                     '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderNegativeKeywords':             '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderSitelinks':                    '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderCalloutExtensions':            '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderStructuredSnippets':           '/rip/manageAdvertiserPerformanceOptimization/json',
  'getConnectOrderCallExtensions':               '/rip/manageAdvertiserPerformanceOptimization/json',
};

async function api(name, id) {
  if(!S.sessionInfo) throw new Error('Session not ready');
  const {post, managePath, commonPath} = S.sessionInfo;
  const primary = EP_PATHS[name] || managePath;
  const body = post ? mkBody(id) : null;

  // Try primary (/rip/manage/json)
  try {
    const u = post ? S.baseUrl+primary+'/'+name : qurl(S.baseUrl+primary+'/'+name, id);
    const r = await bg(u, body);
    if(r&&r.ok) return r.data;
  } catch(e){}

  // Fallback paths
  for (const p of ['/rip/manage/json','/rip/common/json','/rip/creative/json','/rip/report/json','/rip/analytics/json','/rip/json'].filter(x=>x!==primary)) {
    try {
      const u = post ? S.baseUrl+p+'/'+name : qurl(S.baseUrl+p+'/'+name, id);
      const r = await bg(u, body);
      if(r&&r.ok) { console.log('[QA] '+name+' found at '+p); return r.data; }
    } catch(e){}
  }
  throw new Error('Not found');
}

function qurl(base, id) { const u=new URL(base); u.searchParams.set('merchantId',String(id)); return u.toString(); }

// ─── ACCOUNTS ─────────────────────────────────────────────────────────────────
function toggleAdd(f) {
  const p=ge('addp'); const show=f!==undefined?f:(p.style.display==='none'||!p.style.display);
  p.style.display=show?'block':'none'; if(show) setTimeout(()=>ge('add-id').focus(),40);
}
function submitAdd() {
  const id=ge('add-id').value.trim(), lbl=ge('add-label').value.trim();
  if(!id){ge('add-id').style.borderColor='var(--err)';return;}
  ge('add-id').style.borderColor=''; toggleAdd(false);
  ge('add-id').value=''; ge('add-label').value='';
  addAcct(id, lbl||null);
}
function addAcct(id,label) {
  if(S.accounts.find(a=>a.id===id)){selAcct(id);return;}
  const a={id,name:label||'Campaign '+id,data:null,qa:null,status:'idle'};
  S.accounts.push(a); save(); renderSB(); selAcct(id); pull(id);
}
function selAcct(id) {
  S.active=id; renderSB();
  const a=S.accounts.find(a=>a.id===id); if(!a) return;
  ge('tb-sub').textContent=a.name+' · #'+id;
  ge('btn-pull').disabled=false;
  if(a.data){if(ge('btn-export'))if(ge('btn-export'))ge('btn-export').disabled=false;renderAll(a);ge('tabbar').style.display='flex';}
}
function removeAcct(id) {
  S.accounts=S.accounts.filter(a=>a.id!==id);
  if(S.active===id){S.active=null;ge('tabbar').style.display='none';if(ge('btn-export'))ge('btn-export').disabled=true;if(ge('btn-pull'))ge('btn-pull').disabled=true;ge('tb-sub').textContent='No account selected';}
  save(); renderSB();
}
function renderSB() {
  const el=ge('sb-accts');
  if(!S.accounts.length){el.innerHTML='<div style="padding:8px;color:var(--muted);font-size:11px;">No accounts yet.</div>';return;}
  el.innerHTML=S.accounts.map(a=>`<div class="acct${a.id===S.active?' active':''}" data-id="${a.id}"><div class="dot${a.status==='ok'?' ok':a.status==='loading'?' busy':a.status==='error'?' err':''}"></div><div style="flex:1;min-width:0;"><div class="aname">${esc(a.name)}</div><div class="aid">#${a.id}</div></div><button class="rmb" data-rid="${a.id}">&#215;</button></div>`).join('');
  el.querySelectorAll('.acct').forEach(n=>n.addEventListener('click',()=>selAcct(n.dataset.id)));
  el.querySelectorAll('.rmb').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();removeAcct(b.dataset.rid);}));
}
function save(){chrome.storage.local.set({accounts:S.accounts.map(a=>({id:a.id,name:a.name}))});}
function loadAccounts(){chrome.storage.local.get(['accounts'],r=>{if(r.accounts&&r.accounts.length){r.accounts.forEach(a=>S.accounts.push({id:a.id,name:a.name,data:null,qa:null,status:'idle'}));renderSB();}});}

// ─── PULL ─────────────────────────────────────────────────────────────────────
async function pull(id) {
  const acct=S.accounts.find(a=>a.id===id); if(!acct) return;
  if(!S.sessionInfo){alert('Session not ready — wait 2s and retry');return;}
  acct.status='loading'; acct.data=null; renderSB(); showView('dashboard');

  const EPS = [
    {key:'advertiser', name:'getAdvertiserDetail',    lbl:'Campaign detail'},
    // Ad copy - try Connect then standard
    {key:'adcopies',   name:'getConnectOrderAds',                   lbl:'Ad copy (Connect)'},
    {key:'adcopies2',  name:'getLocationAdcopies',                   lbl:'Ad copy (standard)'},
    {key:'adcopies3',  name:'getAdCopies',                          lbl:'Ad copy (alt)'},
    // Keywords - try Connect then standard
    {key:'keywords',   name:'getConnectOrderKeywords',              lbl:'Keywords (Connect)'},
    {key:'keywords2',  name:'getCategoryKeyphrases',               lbl:'Keywords (standard)'},
    // Negative keywords
    {key:'negkw',      name:'getConnectOrderNegativeKeywords',      lbl:'Neg. keywords (Connect)'},
    {key:'negkw2',     name:'getNegativeKeyphrases',               lbl:'Neg. keywords (standard)'},
    // Sitelinks - try Connect then standard
    {key:'sitelinks',  name:'getConnectOrderSitelinks',            lbl:'Sitelinks (Connect)'},
    {key:'sitelinks2', name:'getSitelinks',                        lbl:'Sitelinks (standard)'},
    {key:'sitelinks3', name:'getLocationSitelinks',                lbl:'Sitelinks (alt)'},
    // Callouts
    {key:'callouts',   name:'getConnectOrderCalloutExtensions',    lbl:'Callouts (Connect)'},
    {key:'callouts2',  name:'getCalloutExtensions',                lbl:'Callouts (standard)'},
    {key:'callouts3',  name:'getLocationCalloutExtensions',        lbl:'Callouts (alt)'},
    // Snippets
    {key:'snippets',   name:'getConnectOrderStructuredSnippets',   lbl:'Snippets (Connect)'},
    {key:'snippets2',  name:'getStructuredSnippets',               lbl:'Snippets (standard)'},
    // Call extensions
    {key:'callext',    name:'getConnectOrderCallExtensions',       lbl:'Call ext (Connect)'},
    {key:'callext2',   name:'getCallExtensions',                   lbl:'Call ext (standard)'},
    {key:'locext',     name:'getLocationExtensions',               lbl:'Location extensions'},
    {key:'analytics',  name:'getAnalyticsSettings',   lbl:'Analytics'},
    {key:'diag',       name:'getDiagnosticEvents',    lbl:'Diagnostics'},
    {key:'perf',       name:'getMerchantPerformance', lbl:'Performance'},
    {key:'geo',        name:'getGeoTargets',          lbl:'Geo targeting'},
    {key:'disapprovals',   name:'getDisapprovals',                  lbl:'Ad disapprovals'},
    {key:'kwdisapprovals', name:'getKeyphraseDisapprovals',         lbl:'Keyword disapprovals'},
    {key:'kwdisapprovals',name:'getKeyphraseDisapprovals',  lbl:'Keyword disapprovals'},
    {key:'notes',      name:'getMerchantNotes',       lbl:'Super notes'},
    {key:'adgroups',   name:'getAdGroups',            lbl:'Ad groups'},
    {key:'tickets',    name:'getOptimizationTickets', lbl:'Optimization tickets'},
    {key:'labels',     name:'getLabels',              lbl:'Labels'},
    {key:'tags',       name:'getTags',                lbl:'Tags'},
  ];

  const rows=EPS.map(e=>`<div class="logitem" id="lr-${e.key}"><div class="spin"></div><span style="color:var(--muted)">${e.lbl}</span></div>`).join('');
  sv('view-dashboard',`<div style="max-width:500px"><div style="font-size:13px;font-weight:700;margin-bottom:4px">Pulling #${id}...</div><div style="font-size:11px;color:var(--muted);margin-bottom:10px">${S.baseUrl} · ${S.sessionInfo.loginName}</div><div>${rows}</div></div>`);

  const data={}; let ok=0;
  for(const ep of EPS){
    const row=ge('lr-'+ep.key);
    try{
      // Extract embedded from advertiser detail
      if(data.advertiser&&data.advertiser.result){
        const r=data.advertiser.result;
        const emb={getLocations:{result:r.locations||[]},getBudgets:{result:r.budgets||[]},getLabels:{result:r.labels||[]},getTags:{result:r.tags||[]}};
        if(emb[ep.name]){data[ep.key]=emb[ep.name];if(row)row.innerHTML=`<span style="color:var(--ok);font-weight:700">&#10003;</span><span>${ep.lbl}</span><span style="margin-left:auto;color:var(--muted);font-size:10px">embedded</span>`;ok++;continue;}
      }
      const res=await api(ep.name,id);
      data[ep.key]=res;
      const kb=res?(JSON.stringify(res).length/1024).toFixed(1):'0';
      const has=res&&res.result!==null&&res.result!==undefined;
      if(row)row.innerHTML=`<span style="color:${has?'var(--ok)':'var(--warn)'};font-weight:700">${has?'&#10003;':'!'}</span><span style="color:${has?'var(--text)':'var(--muted)'}">${ep.lbl}</span><span style="margin-left:auto;color:var(--muted);font-size:10px">${kb} KB</span>`;
      ok++;
    }catch(e){
      data[ep.key]=null;
      if(row)row.innerHTML=`<span style="color:var(--err);font-weight:700">&#10007;</span><span style="color:var(--muted)">${ep.lbl}</span><span style="margin-left:auto;color:var(--err);font-size:10px">${e.message}</span>`;
    }
  }

  // Merge alt ad copy endpoint if primary returned empty
  if ((!data.adcopies||!data.adcopies.result) && data.adcopies2&&data.adcopies2.result) {
    data.adcopies = data.adcopies2;
  }
  delete data.adcopies2;

  // Merge alt endpoints - Connect first, then standard fallbacks
  const mergeKey=(p,...alts)=>{for(const a of alts){if((!data[p]||!data[p].result)&&data[a]&&data[a].result){data[p]=data[a];break;}}};
  mergeKey('adcopies',  'adcopies2', 'adcopies3');
  mergeKey('keywords',  'keywords2');
  mergeKey('negkw',     'negkw2');
  mergeKey('sitelinks', 'sitelinks2', 'sitelinks3');
  mergeKey('callouts',  'callouts2', 'callouts3');
  mergeKey('snippets',  'snippets2');
  mergeKey('callext',   'callext2');
  mergeKey('adperf',    'dadperf');

  // Merge keyword performance
  const kwPerfRaw=data.kwperf&&data.kwperf.result;
  if(kwPerfRaw&&data.keywords&&data.keywords.result){
    const perfItems=Array.isArray(kwPerfRaw)?kwPerfRaw:(kwPerfRaw.keywords||kwPerfRaw.keyphrases||kwPerfRaw.items||[]);
    const perfById={},perfByText={};
    perfItems.forEach(p=>{
      const id=String(p.id||p.keyphraseId||'');
      const txt=(p.text||p.keyphrase||'').toLowerCase().trim();
      if(id)perfById[id]=p; if(txt)perfByText[txt]=p;
    });
    const kwItems=Array.isArray(data.keywords.result)?data.keywords.result:(data.keywords.result.keyphrases||data.keywords.result.items||[]);
    kwItems.forEach(k=>{
      const id=String(k.id||k.keyphraseId||'');
      const txt=(k.text||k.keyphrase||'').toLowerCase().trim();
      const p=perfById[id]||perfByText[txt]; if(!p)return;
      k.qualityScore=k.qualityScore??p.qualityScore??p.quality_score??p.qs;
      k.impressions=k.impressions??p.impressions??p.impressionCount;
      k.clicks=k.clicks??p.clicks??p.clickCount;
      k.ctr=k.ctr??p.ctr??p.clickThroughRate;
      k.avgCpc=k.avgCpc??p.avgCpc??p.averageCpc??p.cpc;
      k.avgPosition=k.avgPosition??p.avgPosition??p.averagePosition;
    });
  }

  // Merge ad performance
  const adPerfRaw=data.adperf&&data.adperf.result;
  if(adPerfRaw){
    const adItems=Array.isArray(adPerfRaw)?adPerfRaw:(adPerfRaw.ads||adPerfRaw.items||[]);
    const adMap={};
    adItems.forEach(p=>{const id=String(p.id||'');const h=(p.headline||p.headline1||'').toLowerCase().trim();if(id)adMap[id]=p;if(h)adMap[h]=p;});
    const ads=data.adcopies&&data.adcopies.result?(Array.isArray(data.adcopies.result)?data.adcopies.result:(data.adcopies.result.adcopies||data.adcopies.result.ads||[])):[];
    ads.forEach(a=>{const id=String(a.id||'');const h=(a.headline||a.headline1||'').toLowerCase().trim();const p=adMap[id]||adMap[h];if(!p)return;
      a.impressions=a.impressions??p.impressions;a.clicks=a.clicks??p.clicks;a.ctr=a.ctr??p.ctr;a.avgCpc=a.avgCpc??p.avgCpc??p.cpc;a.conversions=a.conversions??p.conversions;
    });
  }

  // Merge ad group performance
  const agPerfRaw=data.agperf&&data.agperf.result;
  if(agPerfRaw){
    const agItems=Array.isArray(agPerfRaw)?agPerfRaw:(agPerfRaw.adGroups||agPerfRaw.items||[]);
    const agMap={};
    agItems.forEach(p=>{const id=String(p.id||'');const n=(p.name||'').toLowerCase().trim();if(id)agMap[id]=p;if(n)agMap[n]=p;});
    const ags=data.adgroups&&data.adgroups.result?(Array.isArray(data.adgroups.result)?data.adgroups.result:(data.adgroups.result.adGroups||data.adgroups.result.items||[])):[];
    ags.forEach(ag=>{const id=String(ag.id||'');const n=(ag.name||'').toLowerCase().trim();const p=agMap[id]||agMap[n];if(!p)return;
      ag.impressions=ag.impressions??p.impressions;ag.clicks=ag.clicks??p.clicks;ag.ctr=ag.ctr??p.ctr;ag.spend=ag.spend??p.spend??p.cost;ag.conversions=ag.conversions??p.conversions;
    });
  }

  // ── Extract IDs from getSearchEngineStructureForAdvertiser ──────────────────
  // Returns: [{type:'Account', customerId}, {type:'Campaign', merchantId, locationId}]
  const structRaw = data.structure && data.structure.result;
  const structItems = Array.isArray(structRaw) ? structRaw : [];
  
  // Get sub-merchantIds and locationIds from Campaign entries
  const structCampaigns = structItems.filter(x => x.type === 'Campaign');
  const subMerchantId = structCampaigns.length ? String(structCampaigns[0].merchantId) : null;
  const locationIds = structCampaigns.map(x => x.locationId).filter(Boolean);
  const firstLocationId = locationIds.length ? String(locationIds[0]) : null;

  // IDs to try for content endpoints (in priority order):
  // 1. subMerchantId from structure (e.g. 2654551)
  // 2. firstLocationId from structure (e.g. 5668556)
  // 3. original merchantId (e.g. 1536464)
  const contentIds = [...new Set([subMerchantId, firstLocationId, String(id)].filter(Boolean))];

  // Retry content endpoints that returned empty using alt IDs
  const contentEPs = [
    {key:'keywords',  name:'getCategoryKeyphrases'},
    {key:'adcopies',  name:'getLocationAdcopies'},
    {key:'adcopies2', name:'getAdCopies'},
    {key:'negkw',     name:'getNegativeKeyphrases'},
    {key:'sitelinks', name:'getSitelinks'},
    {key:'sitelinks2',name:'getLocationSitelinks'},
    {key:'callouts',  name:'getCalloutExtensions'},
    {key:'callouts2', name:'getLocationCalloutExtensions'},
    {key:'snippets',  name:'getStructuredSnippets'},
    {key:'snippets2', name:'getLocationStructuredSnippets'},
    {key:'callext',   name:'getCallExtensions'},
    {key:'callext2',  name:'getLocationCallExtensions'},
    {key:'geo',       name:'getGeoTargets'},
    {key:'adgroups',  name:'getAdGroups'},
  ];

  for (const altId of contentIds) {
    if (altId === String(id)) continue; // already tried with original id
    for (const ep of contentEPs) {
      if (!data[ep.key] || !data[ep.key].result ||
          (Array.isArray(data[ep.key].result) && data[ep.key].result.length === 0)) {
        try {
          const r = await api(ep.name, altId);
          if (r && r.result && !(Array.isArray(r.result) && r.result.length === 0)) {
            data[ep.key] = r; ok++;
          }
        } catch(e) {}
      }
    }
  }

  // Store structure data for display in Campaign Data tab
  // structItems already extracted above

  acct.data=data; acct.status=ok>0?'ok':'error';
  const d=data.advertiser&&data.advertiser.result;
  if(d&&d.name)acct.name=d.name;
  acct.qa=runQA(data); renderSB();
  if(ge('btn-export'))ge('btn-export').disabled=false;
  ge('tb-sub').textContent=acct.name+' · #'+id;
  ge('tabbar').style.display='flex';
  S.activeView='dashboard'; S.activeTab='overview';
  renderAll(acct);
}
function rePull(){if(S.active)pull(S.active);}

// ─── QA ENGINE ────────────────────────────────────────────────────────────────
function runQA(data) {
  const d=data.advertiser&&data.advertiser.result;
  const R=[]; let i=0;
  const chk=(g,n,s,dt,fx)=>R.push({id:i++,group:g,name:n,status:s,detail:dt||'',fix:fx||''});
  if(!d){chk('Campaign','Data loaded','fail','No data','Check ID and session');return R;}

  // Campaign basics
  chk('Campaign','Status',d.status==='active'?'pass':'warn','Status: '+(d.status||'?'),d.status!=='active'?'Campaign is not active':'');
  const pct=d.fractionFulfilled*100,tpct=d.fractionOfTimeUsed*100,diff=pct-tpct;
  chk('Campaign','Pacing',Math.abs(diff)<10?'pass':diff<-15?'fail':'warn',pct.toFixed(1)+'% spent / '+tpct.toFixed(1)+'% time elapsed',Math.abs(diff)>10?'Review bid strategy and budget':'');
  chk('Campaign','Fulfillment',pct>=90?'pass':pct>=70?'warn':'fail',pct.toFixed(1)+'% of budget fulfilled',pct<70?'Under-delivering — check bids, targeting, quality score':'');
  chk('Campaign','Bid cap',d.bidCapOverride>0?'pass':'warn',d.bidCapOverride>0?'Bid cap: $'+d.bidCapOverride:'No bid cap set','');
  chk('Campaign','Smart bidding',d.isGoogleSmartBiddingEnabled?'pass':'info',d.isGoogleSmartBiddingEnabled?'Google Smart Bidding enabled':'Not enabled','');
  chk('Campaign','Domain set',d.domains&&d.domains.length?'pass':'fail',d.domains&&d.domains[0]?d.domains[0].domain:'No domain configured','');

  // Engines
  const locs=d.locations||[];
  const activeEngs=[...new Set(locs.filter(l=>l.status==='active').map(l=>ENG[l.type]||'Engine '+l.type))];
  chk('Campaign','Active engines',activeEngs.length>0?'pass':'fail','Running: '+(activeEngs.join(', ')||'none'),activeEngs.length===0?'No active segments/engines':'');

  // Labels & Tags
  const lbls=getArr(data,'labels','labels','items',d.labels);
  const tags=getArr(data,'tags','tags','items',d.tags);
  chk('Labels & Tags','Labels',lbls.length>0?'pass':'info',lbls.length>0?'Labels: '+lbls.map(l=>l.name||l).join(', '):'No labels applied','');
  chk('Labels & Tags','Tags',tags.length>0?'pass':'info',tags.length>0?'Tags: '+tags.map(t=>t.name||t).join(', '):'No tags applied','');

  // Performance
  chk('Performance','Impressions',d.impressionsSpent>0?'pass':'fail',(d.impressionsSpent||0).toLocaleString()+' impressions this cycle',d.impressionsSpent===0?'Zero impressions — check segment status and approvals':'');
  chk('Performance','Clicks',d.clicksSpent>0?'pass':d.impressionsSpent>0?'warn':'fail',(d.clicksSpent||0).toLocaleString()+' clicks | CTR: '+(d.impressionsSpent>0?((d.clicksSpent/d.impressionsSpent)*100).toFixed(2)+'%':'N/A'),'');
  chk('Performance','CPC',d.cpc>0&&d.cpc<20?'pass':d.cpc>=20?'warn':'info',d.cpc?'CPC: $'+d.cpc.toFixed(2)+' | Recent: $'+(d.recentCpc||0).toFixed(2):'No CPC data',d.cpc>=20?'High CPC — review bidding strategy':'');

  // Calls / Leads / CPL from performance data
  const perf=data.perf&&data.perf.result;
  if(perf){
    const calls=perf.calls||perf.totalCalls||perf.callCount||0;
    const leads=perf.leads||perf.totalLeads||perf.leadCount||0;
    const cpl=leads>0?'$'+((d.currencySpent||0)/leads).toFixed(2):'N/A';
    chk('Performance','Calls this cycle',calls>0?'pass':'warn',calls+' calls recorded',calls===0?'No calls this cycle — check call tracking':'');
    chk('Performance','Leads this cycle',leads>0?'pass':'info',leads+' leads | CPL: '+cpl,'');
  }

  // Segments
  const active=locs.filter(l=>l.status==='active');
  chk('Segments','Active segments',active.length>0?'pass':'fail',active.length+'/'+locs.length+' segments active',active.length===0?'No active segments — campaign cannot serve ads':'');
  locs.forEach(l=>{if(l.status==='active'&&l.googleBiddingStrategy==null)chk('Segments','"'+l.name+'" bidding','warn','No bidding strategy set on this segment','Set a bidding strategy');});

  // Keywords
  const kws=getArr(data,'keywords','keyphrases','items');
  chk('Keywords','Keywords present',kws.length>0?'pass':'warn',kws.length+' keywords found',kws.length===0?'No keywords returned — check segment setup':'');
  const activeKws=kws.filter(k=>!k.status||k.status==='active');
  const pausedKws=kws.filter(k=>k.status==='paused');
  if(kws.length>0)chk('Keywords','Active keywords',activeKws.length>0?'pass':'fail',activeKws.length+' active, '+pausedKws.length+' paused',activeKws.length===0?'ALL keywords are paused — campaign cannot match queries':'');
  const broad=kws.filter(k=>(k.matchType||'').toLowerCase()==='broad');
  if(broad.length)chk('Keywords','Broad match keywords','warn',broad.length+' broad match keyword(s)','Broad match can waste budget — consider phrase or exact match');

  // Negative keyword conflicts
  const negkws=getArr(data,'negkw','keyphrases','items');
  if(negkws.length&&kws.length){
    const conflicts=[];
    kws.forEach(pk=>{const pt=(pk.text||pk.keyphrase||pk.phrase||'').toLowerCase().trim();negkws.forEach(nk=>{const nt=(nk.text||nk.keyphrase||nk.phrase||'').toLowerCase().trim();if(pt&&nt&&(pt.includes(nt)||nt.includes(pt)))conflicts.push('"'+pt+'" ↔ neg "'+nt+'"');});});
    if(conflicts.length)chk('Keywords','Negative keyword conflicts','fail',conflicts.slice(0,3).join(' | ')+(conflicts.length>3?' +'+(conflicts.length-3)+' more':''),'Remove conflicting negatives or adjust positive keywords');
    else chk('Keywords','Negative conflicts','pass','No negative/positive conflicts detected','');
  }

  // Ad copy
  const ads=getArr(data,'adcopies','adcopies','ads','items');
  chk('Ad Copy','Ads present',ads.length>0?'pass':'fail',ads.length+' ad(s) found',ads.length===0?'No ad copy found':'');
  const actAds=ads.filter(a=>!a.status||a.status==='active');
  chk('Ad Copy','Min 2 active ads',actAds.length>=2?'pass':actAds.length===1?'warn':'fail',actAds.length+' active ads',actAds.length<2?'Best practice: 2–3 ads per group for A/B testing':'');
  ads.forEach(a=>{const h=a.headline||a.headline1||a.title||'';if(h.length>30)chk('Ad Copy','Headline too long','warn','"'+h.slice(0,30)+'..." ('+h.length+' chars)','Headline 1 must be ≤30 characters');});

  // Extensions
  const sl=getArr(data,'sitelinks','sitelinks','items');
  chk('Extensions','Sitelinks ≥ 4',sl.length>=4?'pass':sl.length>0?'warn':'fail',sl.length+' sitelink(s)',sl.length<4?'Add at least 4 sitelinks for better ad visibility':'');
  sl.forEach(s=>{if(!s.description1&&!s.description2)chk('Extensions','Sitelink missing descriptions','warn','"'+(s.displayText||s.text||'?')+'" has no descriptions','Add 2 description lines per sitelink');});
  const co=getArr(data,'callouts','callouts','items');
  chk('Extensions','Callouts ≥ 4',co.length>=4?'pass':co.length>0?'warn':'fail',co.length+' callout(s)',co.length<4?'Add at least 4 callout extensions':'');
  const sn=getArr(data,'snippets','snippets','items');
  chk('Extensions','Structured snippets',sn.length>0?'pass':'warn',sn.length+' structured snippet(s)',sn.length===0?'No structured snippets — add to improve ad visibility':'');
  const ce=getArr(data,'callext','extensions','items');
  chk('Extensions','Call extension',ce.length>0?'pass':'warn',ce.length+' call extension(s)',ce.length===0?'No call extension set — add for local campaigns':'');

  // Analytics
  chk('Analytics','GA4 linked',d.ga4Linked?'pass':'fail',d.ga4Linked?'Linked (property '+( d.googleAnalyticsPropertyId||'?')+')':'Not linked',!d.ga4Linked?'Link a GA4 property for conversion tracking':'');
  chk('Analytics','GA tags',d.includeGoogleAnalyticTags?'pass':'warn',d.includeGoogleAnalyticTags?'GA tags enabled':'Not enabled','');
  chk('Analytics','Analytics email',d.currentLinkedAnalyticsEmail?'pass':'warn',d.currentLinkedAnalyticsEmail||'Not linked','');

  // Call tracking
  chk('Call Tracking','Enabled',d.useCallTrackingOrHaveCallData?'pass':'warn',d.useCallTrackingOrHaveCallData?(d.callTrackingCount||0)+' number(s) provisioned':'Not enabled','');
  if(d.useCallTrackingOrHaveCallData){
    const nums=d.callTrackingNumbers||[];
    chk('Call Tracking','Numbers',nums.length>0?'pass':'fail',nums.length+' tracking number(s)','');
    chk('Call Tracking','Recording',d.recordCalls?'pass':'warn',d.recordCalls?'Call recording on':'Recording is off','');
  }

  // Geo targeting
  const geos=getArr(data,'geo','targets','items');
  chk('Geo Targeting','Geo targets',geos.length>0?'pass':'warn',geos.length>0?geos.length+' location(s): '+geos.slice(0,3).map(g=>g.name||g.locationName||'?').join(', ')+(geos.length>3?' +more':''):'No geo targets found',geos.length===0?'Set geo targeting for local campaigns':'');

  // Disapprovals — split by type
  const allDiss = parseDisapprovals(data);
  const adDissQA = allDiss.filter(d => d.type === 'Ad');
  const kwDissQA = allDiss.filter(d => d.type === 'Keyword');
  const uniqueReasons = [...new Set(allDiss.map(d => d.reason))];
  chk('Disapprovals', 'Ad disapprovals', adDissQA.length === 0 ? 'pass' : 'fail',
    adDissQA.length === 0 ? 'No ad disapprovals for this campaign' :
    adDissQA.length + ' ad disapproval(s) — ' + uniqueReasons.slice(0,2).join(', '),
    adDissQA.length > 0 ? 'Fix disapprovals immediately — affected ads not serving' : '');
  if (kwDissQA.length) {
    chk('Disapprovals', 'Keyword disapprovals', 'warn',
      kwDissQA.length + ' keyword disapproval(s): ' + [...new Set(kwDissQA.map(d=>d.reason))].slice(0,2).join(', '),
      'Review and remove or fix disapproved keywords');
  }

  // Diagnostics
  const na=d.needsAttention||0;
  const attn={0:'Needs MC attention',1:'Needs client attention',2:'Needs both',3:'All good'};
  chk('Diagnostics','Attention flags',na===3?'pass':na===0?'warn':'fail',attn[na]||'?',na!==3?'Resolve outstanding issues':'');
  (d.needsAttentionReasons||[]).forEach(r=>chk('Diagnostics','Flag',na===3?'pass':'fail',String(r),'Resolve with the campaign team'));

  // Optimization Tickets
  const ticks=parseTickets(data);
  const openT=ticks.filter(t=>['Open','In Review','open','in review'].includes(t.ticketStatus||t.status||''));
  if(openT.length){
    openT.forEach(t=>{
      const sev=t.severity||t.severityLevel||'?';
      const notif=t.monitoredNotifications||t.notification||'';
      const critWords=['no google spend','low calls','no spend','zero impression','zero spend','no impressions','account suspended','disapproved','low quality score','low search ctr','low ctr','budget exhausted','below first page','low quality'];
      const isCrit=notif&&critWords.some(p=>notif.toLowerCase().includes(p));
      if(isCrit){
        chk('Optimization Tickets','🚨 CRITICAL: '+notif,'fail','Ticket #'+(t.ticketId||t.id||'?')+' | Severity: '+sev+' | Status: '+(t.ticketStatus||t.status),'Immediate action required — monitored notification triggered');
      } else {
        chk('Optimization Tickets','Open ticket #'+(t.ticketId||t.id||'?'),'warn','Severity: '+sev+' | '+( t.ticketStatus||t.status)+(notif?' | '+notif:''),'Review and resolve this optimization ticket');
      }
    });
  } else {
    chk('Optimization Tickets','Open tickets',ticks.length>0?'pass':'info',ticks.length>0?'No open tickets ('+ticks.length+' total)':'No ticket data available','');
  }

  // Notes
  const notes=getArr(data,'notes','notes','items');
  if(notes.length)chk('Notes','Super notes','info',notes.length+' note(s) | '+( (notes[0]&&(notes[0].note||notes[0].text)||'').slice(0,80)),'');

  return R;
}

function parseDisapprovals(data) {
  const result = [];
  function flat(raw, type) {
    if (!raw) return;
    const items = Array.isArray(raw) ? raw : (raw.disapprovals||raw.items||raw.ads||[]);
    items.forEach(item => {
      if (!item || typeof item !== 'object') return;
      const topics = item.policyTopics || item.disapprovalReasons || [];
      const isDis = item.approvalStatus==='disapproved' || item.syncDisapproved===true || topics.length>0;
      if (!isDis) return;
      const text = item.headline||item.headline1||item.title||item.adTitle||item.text||item.keyphrase||item.displayText||'(no text)';
      const engine = item.engine||item.engineType||'';
      if (topics.length) {
        topics.slice(0,5).forEach(pt => {
          const r = typeof pt==='string' ? pt : (pt.policyTopic||pt.reason||pt.topic||pt.name||'');
          if (r) result.push({type, text, reason:r, engine, status:'disapproved'});
        });
      } else {
        result.push({type, text, reason:item.reason||item.policyTopic||item.approvalStatus||'disapproved', engine, status:'disapproved'});
      }
    });
  }
  flat(data.disapprovals&&data.disapprovals.result, 'Ad');
  flat(data.kwdisapprovals&&data.kwdisapprovals.result, 'Keyword');
  return result.slice(0, 200);
}

function getArr(data, key, ...fields) {
  const res=data[key]&&data[key].result;
  if(!res) return [];
  if(Array.isArray(res)) return res;
  for(const f of fields){if(res[f]&&Array.isArray(res[f]))return res[f];}
  // Try any array property as fallback
  const anyArr = Object.values(res).find(v=>Array.isArray(v));
  if(anyArr) return anyArr;
  return [];
}

// ─── RENDER ───────────────────────────────────────────────────────────────────
function renderAll(acct) {
  renderDash(acct); renderQAView(acct); renderRaw(acct);
  if(S.activeView==='data')renderDataTab(acct,S.activeTab||'overview');
  showView(S.activeView);
}

function renderDash(acct) {
  const d=acct.data&&acct.data.advertiser&&acct.data.advertiser.result;
  if(!d){sv('view-dashboard','<div class="alert err">No campaign data — check ID and session.</div>');return;}
  const pct=(d.fractionFulfilled*100).toFixed(1),tpct=(d.fractionOfTimeUsed*100).toFixed(1);
  const bc=pct>=90?'green':pct>=70?'amber':'red';
  const qa=acct.qa||[],fails=qa.filter(r=>r.status==='fail').length,warns=qa.filter(r=>r.status==='warn').length;
  const crits=qa.filter(r=>r.status==='fail'&&(r.group==='Optimization Tickets'||r.group==='Disapprovals'));

  const lbls=getArr(acct.data,'labels','labels','items',d.labels).map(l=>l.name||l).filter(Boolean);
  const tags=getArr(acct.data,'tags','tags','items',d.tags).map(t=>t.name||t).filter(Boolean);
  const activeEngs=[...new Set((d.locations||[]).filter(l=>l.status==='active').map(l=>ENG[l.type]||'Engine '+l.type))];
  const allEngs=[...new Set((d.locations||[]).map(l=>ENG[l.type]||'Engine '+l.type))];
  const perf=acct.data.perf&&acct.data.perf.result;
  const calls=perf&&(perf.calls||perf.totalCalls||0)||0;
  const leads=perf&&(perf.leads||perf.totalLeads||0)||0;
  const cpl=leads>0?'$'+((d.currencySpent||0)/leads).toFixed(2):'N/A';
  const notes=getArr(acct.data,'notes','notes','items');
  const diss=parseDisapprovals(acct.data);

  sv('view-dashboard',`
    ${crits.length?`<div class="alert err">&#128680; ${crits.length} CRITICAL ticket issue(s) — ${crits.map(c=>c.detail.split('|')[0].trim()).join('; ')}. <span class="lnk" id="qa-lnk">View QA &rarr;</span></div>`:''}
    ${fails>0&&!crits.length?`<div class="alert warn">&#9888; ${fails} QA check(s) failed, ${warns} warning(s). <span class="lnk" id="qa-lnk">View QA &rarr;</span></div>`:''}
    ${diss.length?`<div class="alert err">&#9888; ${diss.length} ad disapproval(s) found. <span class="lnk" id="ad-lnk">View Ad Copy &rarr;</span></div>`:''}
    <div class="card">
      <div class="cardhd">
        <span class="cardtt">${esc(d.name)}</span>
        <div style="display:flex;gap:5px;align-items:center;flex-wrap:wrap;">
          <span class="badge ${d.status==='active'?'active':'paused'}">${d.status}</span>
          ${activeEngs.map(e=>`<span class="badge info" style="font-size:9px">${e}</span>`).join('')}
        </div>
      </div>
      <div class="cardbd">
        <div class="ig" style="margin-bottom:10px;">
          <div>
            ${ir('Campaign ID',d.id)} ${ir('External ID',d.merchantExternalId)}
            ${ir('Account',d.account&&d.account.name)} ${ir('Manager',d.campaignManager&&d.campaignManager.name)}
            ${ir('Vertical',d.vertical)} ${ir('Activated',fmtD(d.firstActivationDate))}
            ${ir('Website',d.domains&&d.domains[0]?`<a class="lnk" href="${d.domains[0].domain}" target="_blank">${d.domains[0].domain}</a>`:'—')}
          </div>
          <div>
            ${ir('Cycle',fmtD(d.currentBeginDate)+' &rarr; '+fmtD(d.currentEndDate))}
            ${ir('All engines',allEngs.join(', ')||'—')}
            ${ir('Smart bidding',d.isGoogleSmartBiddingEnabled?'&#10003; On':'&#10007; Off')}
            ${ir('Bid cap',d.bidCapOverride?'$'+d.bidCapOverride:'Not set')}
            ${lbls.length?ir('Labels',lbls.map(l=>`<span class="tag">${esc(l)}</span>`).join(' ')):''}
            ${tags.length?ir('Tags',tags.map(t=>`<span class="tag" style="background:var(--pud);color:var(--pur)">${esc(t)}</span>`).join(' ')):''}
          </div>
        </div>
        <div class="kpis" style="margin-bottom:10px;">
          <div class="kpi blue"><div class="kpil">Budget</div><div class="kpiv">${fmt$(d.combinedCurrencyTarget)}</div><div class="kpis2">this cycle</div></div>
          <div class="kpi"><div class="kpil">Spent</div><div class="kpiv">${fmt$(d.currencySpent)}</div><div class="kpis2">${pct}%</div></div>
          <div class="kpi green"><div class="kpil">Clicks</div><div class="kpiv">${(d.clicksSpent||0).toLocaleString()}</div><div class="kpis2">CPC ${fmt$(d.cpc)}</div></div>
          <div class="kpi"><div class="kpil">Impr.</div><div class="kpiv">${(d.impressionsSpent||0).toLocaleString()}</div><div class="kpis2">CPM ${fmt$(d.cpm)}</div></div>
          <div class="kpi ${d.pacing===0?'green':'amber'}"><div class="kpil">Pacing</div><div class="kpiv">${d.pacing===0?'OK':d.pacing===1?'Over':'Under'}</div><div class="kpis2">${tpct}% time</div></div>
          <div class="kpi"><div class="kpil">Calls</div><div class="kpiv">${calls}</div><div class="kpis2">this cycle</div></div>
          <div class="kpi"><div class="kpil">Leads</div><div class="kpiv">${leads}</div><div class="kpis2">CPL ${cpl}</div></div>
          <div class="kpi"><div class="kpil">Recent CPC</div><div class="kpiv">${fmt$(d.recentCpc)}</div><div class="kpis2">cap ${fmt$(d.bidCapOverride||0)}</div></div>
        </div>
        <div style="font-size:10px;color:var(--muted);margin-bottom:3px">Fulfillment ${pct}%</div>
        <div class="prog"><div class="progf ${bc}" style="width:${Math.min(pct,100)}%"></div></div>
        <div style="font-size:10px;color:var(--muted);margin-top:7px;margin-bottom:3px">Time elapsed ${tpct}%</div>
        <div class="prog"><div class="progf" style="width:${Math.min(tpct,100)}%;background:var(--muted)"></div></div>
        ${notes.length?`<div class="note-box" style="margin-top:10px"><strong style="color:var(--accent)">&#128203; Super Notes (${notes.length})</strong><div style="margin-top:4px;color:var(--muted)">${esc((notes[0]&&(notes[0].note||notes[0].text)||'').slice(0,250))}</div></div>`:''}
      </div>
    </div>`);
  ge('qa-lnk')&&ge('qa-lnk').addEventListener('click',()=>showView('qa'));
  ge('ad-lnk')&&ge('ad-lnk').addEventListener('click',()=>{showView('data');showTab('ads');});
}

function renderQAView(acct) {
  const qa=acct.qa||[]; if(!qa.length)return;
  const pass=qa.filter(r=>r.status==='pass').length,fail=qa.filter(r=>r.status==='fail').length;
  const warn=qa.filter(r=>r.status==='warn').length,info=qa.filter(r=>r.status==='info').length;
  const groups={}; qa.forEach(r=>{if(!groups[r.group])groups[r.group]=[];groups[r.group].push(r);});
  const html=Object.entries(groups).map(([g,items])=>{
    const gf=items.filter(i=>i.status==='fail').length,gw=items.filter(i=>i.status==='warn').length,gp=items.filter(i=>i.status==='pass').length;
    const ico=gf>0?'&#128308;':gw>0?'&#128993;':'&#128994;';
    const ihtml=items.map(i=>`<div class="qaitem"><div class="qaico ${i.status}">${i.status==='pass'?'&#10003;':i.status==='fail'?'&#10007;':i.status==='warn'?'!':'i'}</div><div style="flex:1;min-width:0"><div class="qanm">${esc(i.name)}</div>${i.detail?`<div class="qadt">${esc(i.detail)}</div>`:''} ${i.fix?`<div class="qafix">&#8594; ${esc(i.fix)}</div>`:''}</div><span class="badge ${i.status==='pass'?'active':i.status==='fail'?'error':i.status==='warn'?'paused':'info'}">${i.status}</span></div>`).join('');
    const gid='qg'+g.replace(/\W/g,'');
    return `<div class="qagrp"><div class="qaghd" data-gid="${gid}"><div class="qagtitle">${ico} ${esc(g)}</div><div class="qagcounts">${gf?`<span class="badge error">${gf}F</span>`:''} ${gw?`<span class="badge paused">${gw}W</span>`:''} ${gp?`<span class="badge active">${gp}P</span>`:''}</div></div><div class="qaitems ${gf||gw?'open':''}" id="${gid}">${ihtml}</div></div>`;
  }).join('');
  ge('qa-empty').style.display='none'; ge('qa-results').style.display='block';
  ge('qa-results').innerHTML=`<div class="qasumm"><div class="qastat pass"><div class="qanum">${pass}</div><div class="qalbl">Passed</div></div><div class="qastat fail"><div class="qanum">${fail}</div><div class="qalbl">Failed</div></div><div class="qastat warn"><div class="qanum">${warn}</div><div class="qalbl">Warnings</div></div><div class="qastat info"><div class="qanum">${info}</div><div class="qalbl">Info</div></div></div>${html}`;
  document.querySelectorAll('.qaghd').forEach(h=>h.addEventListener('click',()=>ge(h.dataset.gid)?.classList.toggle('open')));
}

function renderDataTab(acct,tab) {
  const d=acct.data&&acct.data.advertiser&&acct.data.advertiser.result;
  if(!d){sv('view-data','<div class="alert err" style="margin:12px">No campaign data.</div>');return;}
  const builders={overview:()=>bOverview(d,acct.data),budget:()=>bBudget(d),segments:()=>bSegments(d),keywords:()=>bKeywords(acct.data),ads:()=>bAds(acct.data),extensions:()=>bExtensions(acct.data),analytics:()=>bAnalytics(d),callt:()=>bCallT(d),geo:()=>bGeo(acct.data),adgroups:()=>bAdGroups(acct.data,d),tickets:()=>bTickets(acct.data)};
  sv('view-data',(builders[tab]||builders.overview)());
  if(tab==='segments'||tab==='adgroups') setTimeout(bindEngineFilter,50);
}

function bOverview(d,data) {
  const lbls=getArr(data,'labels','labels','items',d.labels).map(l=>l.name||l).filter(Boolean);
  const tags=getArr(data,'tags','tags','items',d.tags).map(t=>t.name||t).filter(Boolean);
  const engs=[...new Set((d.locations||[]).map(l=>ENG[l.type]||'Engine '+l.type))];
  const notes=getArr(data,'notes','notes','items');
  return `<div class="card"><div class="cardhd"><span class="cardtt">Campaign overview</span></div><div class="cardbd">
    <div class="ig">
      <div>${ir('Name',d.name)}${ir('ID',d.id)}${ir('External ID',d.merchantExternalId)}${ir('Account',d.account&&d.account.name)}${ir('Manager',d.campaignManager&&d.campaignManager.name)}${ir('Org',d.organizationPath)}${ir('Vertical',d.vertical)}</div>
      <div>${ir('Status',`<span class="badge ${d.status==='active'?'active':'paused'}">${d.status}</span>`)}${ir('Activated',fmtD(d.firstActivationDate))}${ir('Cycle',fmtD(d.currentBeginDate)+' &rarr; '+fmtD(d.currentEndDate))}${ir('Website',d.domains&&d.domains[0]?d.domains[0].domain:'—')}${ir('Engines',engs.join(', ')||'—')}${ir('Smart bidding',d.isGoogleSmartBiddingEnabled?'On':'Off')}
        ${ir('Labels',lbls.length?lbls.map(l=>`<span class="tag">${esc(l)}</span>`).join(' '):'None')}
        ${ir('Tags',tags.length?tags.map(t=>`<span class="tag" style="background:var(--pud);color:var(--pur)">${esc(t)}</span>`).join(' '):'None')}</div>
    </div>
    ${notes.length?`<div style="margin-top:10px"><div style="font-size:11px;font-weight:700;margin-bottom:6px">Super Notes (${notes.length})</div>${notes.map(n=>`<div style="background:var(--surface);border-radius:6px;padding:8px;margin-bottom:6px;font-size:11px;color:var(--muted)">${esc(n.note||n.text||JSON.stringify(n))}</div>`).join('')}</div>`:''}
  </div></div>`;
}

function bBudget(d) {
  const bs=d.budgets||[];
  const tT=bs.reduce((s,b)=>s+(b.targetRetailSpend||0),0),tS=bs.reduce((s,b)=>s+(b.retailCurrencySpent||0),0);
  const rows=bs.map(b=>{const p=b.targetRetailSpend>0?((b.retailCurrencySpent/b.targetRetailSpend)*100).toFixed(1)+'%':'—';const st={0:'active',1:'completed',9:'completed'}[b.statusBits]||'paused';return`<tr><td>${fmtD(b.beginDate)}</td><td>${fmtD(b.endDate)}</td><td>${fmt$(b.targetRetailSpend)}</td><td>${fmt$(b.retailCurrencySpent)}</td><td style="color:${b.currencyRolledOver>0?'var(--ok)':b.currencyRolledOver<0?'var(--err)':'var(--text)'}">${fmt$(b.currencyRolledOver)}</td><td>${(b.clicksSpent||0).toLocaleString()}</td><td>${p}</td><td><span class="badge ${st==='active'?'active':st==='completed'?'purple':'paused'}">${st}</span></td></tr>`;}).join('');
  return `<div class="card"><div class="cardhd"><span class="cardtt">Budget cycles &mdash; ${bs.length}</span></div><div class="cardbd"><div class="kpis"><div class="kpi blue"><div class="kpil">Total budgeted</div><div class="kpiv">${fmt$(tT)}</div></div><div class="kpi green"><div class="kpil">Total spent</div><div class="kpiv">${fmt$(tS)}</div></div><div class="kpi"><div class="kpil">Cycles</div><div class="kpiv">${bs.length}</div></div></div></div><div class="tw"><table><thead><tr><th>Start</th><th>End</th><th>Target</th><th>Spent</th><th>Rollover</th><th>Clicks</th><th>Fulfilled</th><th>Status</th></tr></thead><tbody>${rows||noRows(8)}</tbody></table></div></div>`;
}

function bSegments(d) {
  const locs=d.locations||[];
  const engs=[...new Set(locs.map(l=>ENG[l.type]||'Engine '+l.type))];
  const filterBtns=engs.map(e=>`<button class="efbtn ef-seg" data-eng="${e}">${e}</button>`).join('');
  const rows=locs.map(l=>`<tr data-eng="${ENG[l.type]||'Engine '+l.type}"><td style="color:var(--muted)">${l.id}</td><td><strong>${esc(l.name)}</strong></td><td>${ENG[l.type]||'Type '+l.type}</td><td><span class="badge ${l.status==='active'?'active':'paused'}">${l.status}</span></td><td>${l.googleBiddingStrategy!=null?'Strategy '+l.googleBiddingStrategy:'—'}</td><td>${l.googleBiddingStrategyTarget!=null?fmt$(l.googleBiddingStrategyTarget):'—'}</td></tr>`).join('');
  return `<div class="card"><div class="cardhd"><span class="cardtt">Segments &mdash; ${locs.length}</span><div style="display:flex;gap:4px;flex-wrap:wrap">${filterBtns}<button class="efbtn ef-all-seg">All</button></div></div><div class="tw"><table id="seg-tbl"><thead><tr><th>ID</th><th>Name</th><th>Engine</th><th>Status</th><th>Bidding</th><th>Target CPA</th></tr></thead><tbody>${rows||noRows(6)}</tbody></table></div></div>`;
}

function bKeywords(data) {
  const kws=getArr(data,'keywords','keyphrases','items');
  const negs=getArr(data,'negkw','keyphrases','items');
  const rows=kws.map(k=>`<tr><td>${esc(k.text||k.keyphrase||k.phrase||'—')}</td><td>${k.matchType||k.type||'—'}</td><td><span class="badge ${!k.status||k.status==='active'?'active':'paused'}">${k.status||'active'}</span></td><td>${k.categoryName||k.category||'—'}</td><td>${k.bid!=null?fmt$(k.bid):'—'}</td></tr>`).join('');
  const negRows=negs.map(k=>`<tr><td>${esc(k.text||k.keyphrase||k.phrase||'—')}</td><td>${k.matchType||k.type||'—'}</td><td>${k.categoryName||'—'}</td></tr>`).join('');
  return `<div class="card"><div class="cardhd"><span class="cardtt">Keywords &mdash; ${kws.length}</span></div><div class="tw"><table><thead><tr><th>Keyword</th><th>Match</th><th>Status</th><th>Category</th><th>Bid</th></tr></thead><tbody>${rows||noRows(5)}</tbody></table></div></div>
  ${negs.length?`<div class="card"><div class="cardhd"><span class="cardtt">Negative keywords &mdash; ${negs.length}</span></div><div class="tw"><table><thead><tr><th>Keyword</th><th>Match</th><th>Category</th></tr></thead><tbody>${negRows}</tbody></table></div></div>`:''}`;
}

function bAds(data) {
  const ads=getArr(data,'adcopies','adcopies','ads','items');
  const diss=getArr(data,'disapprovals','disapprovals','items');
  const rows=ads.map(a=>`<tr><td>${esc(a.headline||a.headline1||a.title||'—')}</td><td>${esc(a.headline2||'—')}</td><td>${esc(a.description||a.description1||'—')}</td><td>${esc(a.displayUrl||a.display_url||'—')}</td><td><span class="badge ${!a.status||a.status==='active'?'active':'paused'}">${a.status||'active'}</span></td></tr>`).join('');
  const disRows=diss.map(x=>`<tr><td style="color:var(--err)">${esc(x.headline||x.adTitle||'—')}</td><td>${esc(x.reason||x.policyTopic||'—')}</td></tr>`).join('');
  return `<div class="card"><div class="cardhd"><span class="cardtt">Ad copy &mdash; ${ads.length}</span></div><div class="tw"><table><thead><tr><th>Headline 1</th><th>Headline 2</th><th>Description</th><th>Display URL</th><th>Status</th></tr></thead><tbody>${rows||noRows(5)}</tbody></table></div></div>
  ${diss.length?`<div class="card"><div class="cardhd"><span class="cardtt" style="color:var(--err)">&#9888; Disapprovals &mdash; ${diss.length}</span></div><div class="tw"><table><thead><tr><th>Ad</th><th>Reason</th></tr></thead><tbody>${disRows}</tbody></table></div></div>`:''}`;
}

function bExtensions(data) {
  const sl=getArr(data,'sitelinks','sitelinks','items');
  const co=getArr(data,'callouts','callouts','items');
  const sn=getArr(data,'snippets','snippets','items');
  const ce=getArr(data,'callext','extensions','items');
  const le=getArr(data,'locext','extensions','items');
  const slRows=sl.map(s=>`<tr><td>${esc(s.displayText||s.text||'—')}</td><td style="font-size:10px;max-width:140px;overflow:hidden;text-overflow:ellipsis">${esc(s.finalUrl||s.url||'—')}</td><td>${esc(s.description1||'—')}</td><td>${esc(s.description2||'—')}</td></tr>`).join('');
  const coRows=co.map(c=>`<tr><td>${esc(c.text||c.calloutText||JSON.stringify(c))}</td></tr>`).join('');
  const snRows=sn.map(s=>`<tr><td>${esc(s.header||'—')}</td><td>${esc((s.values||[]).join(', '))}</td></tr>`).join('');
  const ceRows=ce.map(c=>`<tr><td><strong>${fmtPh(c.phoneNumber||c.phone||'')}</strong></td><td>${c.countryCode||'—'}</td></tr>`).join('');
  return `
    <div class="card"><div class="cardhd"><span class="cardtt">Sitelinks &mdash; ${sl.length} ${sl.length<4?'<span class="badge paused">Need 4+</span>':''}</span></div><div class="tw"><table><thead><tr><th>Text</th><th>URL</th><th>Desc 1</th><th>Desc 2</th></tr></thead><tbody>${slRows||noRows(4)}</tbody></table></div></div>
    <div class="card"><div class="cardhd"><span class="cardtt">Callout extensions &mdash; ${co.length} ${co.length<4?'<span class="badge paused">Need 4+</span>':''}</span></div><div class="tw"><table><thead><tr><th>Text</th></tr></thead><tbody>${coRows||noRows(1)}</tbody></table></div></div>
    <div class="card"><div class="cardhd"><span class="cardtt">Structured snippets &mdash; ${sn.length} ${sn.length===0?'<span class="badge error">Missing</span>':''}</span></div><div class="tw"><table><thead><tr><th>Header</th><th>Values</th></tr></thead><tbody>${snRows||noRows(2)}</tbody></table></div></div>
    <div class="card"><div class="cardhd"><span class="cardtt">Call extensions &mdash; ${ce.length}</span></div><div class="tw"><table><thead><tr><th>Phone</th><th>Country</th></tr></thead><tbody>${ceRows||noRows(2)}</tbody></table></div></div>
    <div class="card"><div class="cardhd"><span class="cardtt">Location extensions &mdash; ${le.length}</span></div><div class="cardbd" style="color:var(--muted);font-size:11px">${le.length?le.map(e=>esc(e.businessName||JSON.stringify(e))).join('<br>'):'No location extensions'}</div></div>`;
}

function bAnalytics(d) {
  const cs=d.conversionSource;
  return `<div class="card"><div class="cardhd"><span class="cardtt">Analytics & tracking</span></div><div class="cardbd"><div class="ig">
    <div>${ir('GA4 linked',d.ga4Linked?'<span style="color:var(--ok)">&#10003; Yes</span>':'<span style="color:var(--err)">&#10007; No</span>')}${ir('Email',d.currentLinkedAnalyticsEmail)}${ir('Property ID',d.googleAnalyticsPropertyId)}${ir('Last GA4',d.googleAnalytics4LastSessionDate)}${ir('GA tags',d.includeGoogleAnalyticTags?'Yes':'No')}</div>
    <div>${cs&&cs.property?ir('Account',cs.property.accountName):''}${cs&&cs.property?ir('Property',cs.property.propertyName):''}${ir('Enhanced',d.useEnhancedAnalytics?'Yes':'No')}${ir('Smart bidding',d.isGoogleSmartBiddingEnabled?'On':'Off')}${ir('Auto adjustments',d.automaticBidAdjustments?'Yes':'No')}</div>
  </div></div></div>`;
}

function bCallT(d) {
  const nums=d.callTrackingNumbers||[];
  const rows=nums.map(n=>`<tr><td style="color:var(--muted)">${n.id}</td><td><strong>${fmtPh(n.frontendPhoneNumber)}</strong></td><td>${fmtPh(n.backendPhoneNumber)}</td><td>${n.requestTollFree?'Toll-free':'Local'}</td></tr>`).join('');
  return `<div class="card"><div class="cardhd"><span class="cardtt">Call tracking</span></div><div class="cardbd"><div class="ig" style="margin-bottom:10px"><div>${ir('Enabled',d.useCallTrackingOrHaveCallData?'Yes':'No')}${ir('Numbers',d.callTrackingCount||0)}${ir('Recording',d.recordCalls?'Yes':'No')}${ir('Whisper',d.useCallWhisper?'Yes':'No')}</div></div></div><div class="tw"><table><thead><tr><th>ID</th><th>Tracking #</th><th>Forwards to</th><th>Type</th></tr></thead><tbody>${rows||noRows(4)}</tbody></table></div></div>`;
}

function bGeo(data) {
  const geos=getArr(data,'geo','targets','items');
  const rows=geos.map(g=>`<tr><td><strong>${esc(g.name||g.locationName||'—')}</strong></td><td>${esc(g.type||g.locationType||'—')}</td><td>${esc(g.countryCode||'—')}</td><td>${g.radius?g.radius+' '+( g.radiusUnit||'mi'):'—'}</td></tr>`).join('');
  return `<div class="card"><div class="cardhd"><span class="cardtt">Geo targeting &mdash; ${geos.length} location(s)</span></div><div class="tw"><table><thead><tr><th>Location</th><th>Type</th><th>Country</th><th>Radius</th></tr></thead><tbody>${rows||noRows(4)}</tbody></table></div></div>`;
}

function bAdGroups(data,d) {
  const ags=getArr(data,'adgroups','adGroups','items');
  const locs=d.locations||[];
  const engs=[...new Set(locs.map(l=>ENG[l.type]||'Engine '+l.type))];
  const filterBtns=engs.map(e=>`<button class="efbtn ef-ag" data-eng="${e}">${e}</button>`).join('');
  if(!ags.length) return `<div class="card"><div class="cardhd"><span class="cardtt">Ad groups</span><div style="display:flex;gap:4px">${filterBtns}<button class="efbtn ef-all-ag">All</button></div></div><div class="cardbd" style="color:var(--muted);font-size:11px">No ad group data returned for this instance.</div></div>`;
  const zeroKw=ags.filter(ag=>ag.status==='active'&&((ag.keywordCount||0)===0||(ag.activeKeywords||ag.activeKeywordCount||0)===0));
  const rows=ags.map(ag=>{const kc=ag.keywordCount||ag.keywords||0,ak=ag.activeKeywords||ag.activeKeywordCount||0,warn=ag.status==='active'&&(kc===0||ak===0);return`<tr data-eng="${esc(ag.engineType||ag.engine||'?')}"><td>${esc(ag.name||ag.adGroupName||'—')}</td><td>${esc(ag.engineType||ag.engine||'—')}</td><td><span class="badge ${!ag.status||ag.status==='active'?'active':'paused'}">${ag.status||'active'}</span></td><td style="color:${warn?'var(--err)':'var(--text)'}">${kc}${warn?' &#9888;':''}</td><td>${ak}</td></tr>`;}).join('');
  return `${zeroKw.length?`<div class="alert err">&#9888; ${zeroKw.length} active ad group(s) have 0 or all-paused keywords: ${zeroKw.map(ag=>esc(ag.name||'?')).join(', ')}</div>`:''}
    <div class="card"><div class="cardhd"><span class="cardtt">Ad groups &mdash; ${ags.length}</span><div style="display:flex;gap:4px;flex-wrap:wrap">${filterBtns}<button class="efbtn ef-all-ag">All</button></div></div><div class="tw"><table id="ag-tbl"><thead><tr><th>Name</th><th>Engine</th><th>Status</th><th>Total KW</th><th>Active KW</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}

function parseTickets(data) {
  const raw = data.tickets && data.tickets.result;
  if (!raw) return [];
  if (Array.isArray(raw)) return raw;
  // Try all array properties
  for (const key of ['tickets','items','openTickets','data','results']) {
    if (raw[key] && Array.isArray(raw[key])) return raw[key];
  }
  const anyArr = Object.values(raw).find(v=>Array.isArray(v));
  return anyArr || [];
}

function bTickets(data) {
  const ticks=parseTickets(data);
  if(!ticks.length) return `<div class="card"><div class="cardhd"><span class="cardtt">Optimization Tickets</span></div><div class="cardbd" style="color:var(--muted);font-size:11px">No ticket data returned.</div></div>`;
  const rows=ticks.map(t=>{
    const notif=t.monitoredNotifications||t.notification||'';
    const critWords2=['no google spend','low calls','no spend','zero impression','no impressions','disapproved','low quality score','low search ctr','low ctr','low quality'];
    const isCrit=notif&&critWords2.some(p=>notif.toLowerCase().includes(p));
    return`<tr style="${isCrit?'background:rgba(239,68,68,.05)':''}"><td>${t.ticketId||t.id||'—'}</td><td>${t.severity||'—'}</td><td><span class="badge ${['Open','open'].includes(t.ticketStatus||t.status)?'error':['In Review','in review'].includes(t.ticketStatus||t.status)?'paused':'active'}">${t.ticketStatus||t.status||'?'}</span></td><td style="color:${isCrit?'var(--err)':'var(--text)'}">${esc(notif||'—')}</td><td>${t.agentAssigned||'—'}</td><td>${fmtD(t.whenCreated||t.createdDate)}</td></tr>`;}).join('');
  return `<div class="card"><div class="cardhd"><span class="cardtt">Optimization Tickets &mdash; ${ticks.length}</span></div><div class="tw"><table><thead><tr><th>ID</th><th>Severity</th><th>Status</th><th>Monitored Notifications</th><th>Agent</th><th>Created</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}

function renderRaw(acct) {
  const keys=Object.keys(acct.data||{}); if(!keys.length)return;
  const tabs=keys.map((k,i)=>`<div class="tab ${i===0?'active':''}" data-rk="${k}">${k}</div>`).join('');
  sv('view-raw',`<div class="card"><div class="cardhd"><span class="cardtt">Raw JSON</span><button class="btng btn" id="btn-craw" style="height:24px;font-size:10px">Copy</button></div><div class="tabbar" id="raw-tabs" style="border-bottom:1px solid var(--border)">${tabs}</div><div class="cardbd" style="padding:10px"><div class="raw" id="raw-box">${esc(JSON.stringify(acct.data[keys[0]],null,2))}</div></div></div>`);
  window._rk=keys[0];window._rd=acct.data;
  document.querySelectorAll('#raw-tabs .tab').forEach(t=>t.addEventListener('click',()=>{document.querySelectorAll('#raw-tabs .tab').forEach(x=>x.classList.remove('active'));t.classList.add('active');window._rk=t.dataset.rk;ge('raw-box').textContent=JSON.stringify(window._rd[window._rk],null,2);}));
  ge('btn-craw').addEventListener('click',()=>navigator.clipboard.writeText(JSON.stringify(window._rd[window._rk],null,2)).then(()=>alert('Copied!')));
}

// ─── ENGINE FILTER ────────────────────────────────────────────────────────────
function bindEngineFilter() {
  document.querySelectorAll('.ef-seg').forEach(b=>b.addEventListener('click',()=>{
    document.querySelectorAll('#seg-tbl tr[data-eng]').forEach(r=>r.style.display=r.dataset.eng===b.dataset.eng?'':'none');
    document.querySelectorAll('.ef-seg').forEach(x=>x.classList.remove('active')); b.classList.add('active');
  }));
  document.querySelectorAll('.ef-all-seg').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('#seg-tbl tr[data-eng]').forEach(r=>r.style.display='');document.querySelectorAll('.ef-seg').forEach(x=>x.classList.remove('active'));}));
  document.querySelectorAll('.ef-ag').forEach(b=>b.addEventListener('click',()=>{
    document.querySelectorAll('#ag-tbl tr[data-eng]').forEach(r=>r.style.display=r.dataset.eng===b.dataset.eng?'':'none');
    document.querySelectorAll('.ef-ag').forEach(x=>x.classList.remove('active')); b.classList.add('active');
  }));
  document.querySelectorAll('.ef-all-ag').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('#ag-tbl tr[data-eng]').forEach(r=>r.style.display='');document.querySelectorAll('.ef-ag').forEach(x=>x.classList.remove('active'));}));
}

// ─── NAV ──────────────────────────────────────────────────────────────────────
function showView(n) {
  S.activeView=n;
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  ge('view-'+n)?.classList.add('active');
  document.querySelectorAll('.sbi').forEach(i=>i.classList.remove('active'));
  ge('nav-'+n)?.classList.add('active');
  ge('tb-title').textContent={dashboard:'Dashboard',qa:'QA Engine',data:'Campaign Data',raw:'Raw JSON'}[n]||n;
  ge('tabbar').style.display=n==='data'?'flex':'none';
  if(n==='data'){const a=S.accounts.find(a=>a.id===S.active);if(a&&a.data)renderDataTab(a,S.activeTab||'overview');}
}
function showTab(t) {
  S.activeTab=t;
  document.querySelectorAll('.tab').forEach(el=>el.classList.remove('active'));
  ge('tab-'+t)?.classList.add('active');
  const a=S.accounts.find(a=>a.id===S.active);
  if(a&&a.data)renderDataTab(a,t);
}

// ─── EXPORT ───────────────────────────────────────────────────────────────────
function toggleExportMenu() {
  const m = ge('export-menu');
  m.style.display = m.style.display === 'none' ? 'block' : 'none';
}
function closeExportMenu() {
  ge('export-menu').style.display = 'none';
}

// ─── GOOGLE SHEETS EXPORT ─────────────────────────────────────────────────────
async function exportGSheet() {
  const acct = S.accounts.find(a => a.id === S.active);
  if (!acct || !acct.data) return;
  const d = acct.data.advertiser && acct.data.advertiser.result;
  if (!d) return;

  // Build all data as rows
  const allRows = buildExportRows(acct, d);

  // Encode as CSV and open in Google Sheets via import URL
  const csv = allRows.map(r => r.map(v => '"' + String(v||'').replace(/"/g,'""') + '"').join(',')).join('\n');
  const b64 = btoa(unescape(encodeURIComponent(csv)));

  // Create a data URI and open Google Sheets import
  // Best approach: open Sheets with a pre-filled URL
  const sheetsUrl = 'https://docs.google.com/spreadsheets/d/create?usp=sheets_home';

  // Since we can't directly import CSV via URL without API auth,
  // we'll copy to clipboard and open Sheets so user can paste
  await navigator.clipboard.writeText(csv);

  // Open blank Google Sheet
  const tab = window.open(sheetsUrl, '_blank');

  // Show notification
  showToast('CSV copied to clipboard! In the new Google Sheet: File → Import → Paste data', 'info', 5000);
}

// ─── PDF EXPORT ───────────────────────────────────────────────────────────────
function exportPDF() {
  const acct = S.accounts.find(a => a.id === S.active);
  if (!acct || !acct.data) return;
  const d = acct.data.advertiser && acct.data.advertiser.result;
  if (!d) return;

  const pct = (d.fractionFulfilled*100).toFixed(1);
  const tpct = (d.fractionOfTimeUsed*100).toFixed(1);
  const qa = acct.qa || [];
  const fails = qa.filter(r=>r.status==='fail').length;
  const warns = qa.filter(r=>r.status==='warn').length;
  const pass = qa.filter(r=>r.status==='pass').length;
  const lbls = getArr(acct.data,'labels','labels','items',d.labels).map(l=>l.name||l).filter(Boolean);
  const tags = getArr(acct.data,'tags','tags','items',d.tags).map(t=>t.name||t).filter(Boolean);
  const engs = [...new Set((d.locations||[]).filter(l=>l.status==='active').map(l=>ENG[l.type]||'Engine '+l.type))];
  const perf = acct.data.perf && acct.data.perf.result;
  const calls = perf&&(perf.calls||perf.totalCalls||0)||0;
  const leads = perf&&(perf.leads||perf.totalLeads||0)||0;
  const cpl = leads>0?'$'+((d.currencySpent||0)/leads).toFixed(2):'N/A';
  const groups = {};
  qa.forEach(r => { if(!groups[r.group]) groups[r.group]=[]; groups[r.group].push(r); });

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>QA Report — ${d.name}</title>
  <style>
    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:12px;color:#1a1a2e;margin:0;padding:24px;}
    h1{font-size:20px;font-weight:800;color:#1a1a2e;margin-bottom:4px;}
    .sub{color:#6b7280;font-size:12px;margin-bottom:20px;}
    .section{margin-bottom:20px;}
    .section h2{font-size:13px;font-weight:700;color:#1a56db;border-bottom:2px solid #e5e7eb;padding-bottom:4px;margin-bottom:10px;}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 20px;margin-bottom:12px;}
    .row{display:flex;gap:8px;padding:3px 0;border-bottom:1px solid #f3f4f6;font-size:11px;}
    .lbl{color:#6b7280;min-width:120px;flex-shrink:0;} .val{font-weight:500;}
    .kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;}
    .kpi{background:#f8f9fa;border-radius:6px;padding:10px;border:1px solid #e5e7eb;}
    .kl{font-size:9px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px;}
    .kv{font-size:16px;font-weight:800;color:#1a1a2e;}
    .ks{font-size:10px;color:#9ca3af;}
    .qa-summ{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;}
    .qs{border-radius:6px;padding:10px;text-align:center;}
    .qs.pass{background:#f0fdf4;} .qs.fail{background:#fef2f2;} .qs.warn{background:#fffbeb;} .qs.info{background:#eff6ff;}
    .qn{font-size:22px;font-weight:800;} .qn.pass{color:#16a34a;} .qn.fail{color:#dc2626;} .qn.warn{color:#d97706;} .qn.info{color:#2563eb;}
    .ql{font-size:10px;color:#6b7280;}
    .qgroup{margin-bottom:8px;}
    .qgh{font-size:11px;font-weight:700;padding:6px 10px;background:#f8f9fa;border-radius:4px;margin-bottom:4px;}
    .qi{display:flex;gap:8px;padding:5px 10px;border-bottom:1px solid #f3f4f6;font-size:11px;}
    .qico{width:14px;height:14px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;flex-shrink:0;}
    .qico.pass{background:#dcfce7;color:#16a34a;} .qico.fail{background:#fee2e2;color:#dc2626;} .qico.warn{background:#fef3c7;color:#d97706;} .qico.info{background:#dbeafe;color:#2563eb;}
    .qn2{font-weight:600;} .qd{color:#6b7280;margin-top:1px;} .qf{color:#d97706;font-size:10px;margin-top:1px;}
    .badge{display:inline-block;padding:1px 7px;border-radius:20px;font-size:10px;font-weight:700;} 
    .badge.ok{background:#dcfce7;color:#16a34a;} .badge.warn{background:#fef3c7;color:#d97706;} .badge.err{background:#fee2e2;color:#dc2626;}
    .prog{height:6px;background:#e5e7eb;border-radius:3px;margin-top:4px;}
    .pf{height:100%;border-radius:3px;}
    table{width:100%;border-collapse:collapse;font-size:11px;margin-top:6px;}
    th{text-align:left;padding:5px 8px;font-size:9px;font-weight:700;color:#6b7280;text-transform:uppercase;border-bottom:1px solid #e5e7eb;background:#f9fafb;}
    td{padding:5px 8px;border-bottom:1px solid #f3f4f6;}
    .tag{display:inline-block;background:#f3f4f6;color:#374151;padding:1px 6px;border-radius:3px;font-size:10px;margin:1px;}
    @media print{body{padding:0;}}
  </head><body>
  <h1>MatchCraft QA Report</h1>
  <div class="sub">Campaign: <strong>${d.name}</strong> · ID: ${d.id} · Generated: ${new Date().toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</div>
  
  <div class="section">
    <h2>Campaign Overview</h2>
    <div class="grid">
      <div>
        <div class="row"><span class="lbl">Account</span><span class="val">${d.account&&d.account.name||'—'}</span></div>
        <div class="row"><span class="lbl">Status</span><span class="val"><span class="badge ${d.status==='active'?'ok':'warn'}">${d.status}</span></span></div>
        <div class="row"><span class="lbl">Campaign ID</span><span class="val">${d.id}</span></div>
        <div class="row"><span class="lbl">Vertical</span><span class="val">${d.vertical||'—'}</span></div>
        <div class="row"><span class="lbl">Active Engines</span><span class="val">${engs.join(', ')||'None'}</span></div>
        <div class="row"><span class="lbl">Labels</span><span class="val">${lbls.map(l=>`<span class="tag">${l}</span>`).join(' ')||'None'}</span></div>
        <div class="row"><span class="lbl">Tags</span><span class="val">${tags.map(t=>`<span class="tag">${t}</span>`).join(' ')||'None'}</span></div>
      </div>
      <div>
        <div class="row"><span class="lbl">Cycle</span><span class="val">${fmtD(d.currentBeginDate)} → ${fmtD(d.currentEndDate)}</span></div>
        <div class="row"><span class="lbl">Website</span><span class="val">${d.domains&&d.domains[0]&&d.domains[0].domain||'—'}</span></div>
        <div class="row"><span class="lbl">Manager</span><span class="val">${d.campaignManager&&d.campaignManager.name||'—'}</span></div>
        <div class="row"><span class="lbl">Smart Bidding</span><span class="val">${d.isGoogleSmartBiddingEnabled?'Enabled':'Not enabled'}</span></div>
        <div class="row"><span class="lbl">Bid Cap</span><span class="val">${d.bidCapOverride?'$'+d.bidCapOverride:'Not set'}</span></div>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>Performance</h2>
    <div class="kpis">
      <div class="kpi"><div class="kl">Budget</div><div class="kv">${fmt$(d.combinedCurrencyTarget)}</div><div class="ks">this cycle</div></div>
      <div class="kpi"><div class="kl">Spent</div><div class="kv">${fmt$(d.currencySpent)}</div><div class="ks">${pct}% fulfilled</div></div>
      <div class="kpi"><div class="kl">Clicks</div><div class="kv">${(d.clicksSpent||0).toLocaleString()}</div><div class="ks">CPC ${fmt$(d.cpc)}</div></div>
      <div class="kpi"><div class="kl">Impressions</div><div class="kv">${(d.impressionsSpent||0).toLocaleString()}</div><div class="ks">CPM ${fmt$(d.cpm)}</div></div>
      <div class="kpi"><div class="kl">Calls</div><div class="kv">${calls}</div><div class="ks">this cycle</div></div>
      <div class="kpi"><div class="kl">Leads</div><div class="kv">${leads}</div><div class="ks">CPL ${cpl}</div></div>
      <div class="kpi"><div class="kl">Pacing</div><div class="kv">${d.pacing===0?'OK':d.pacing===1?'Over':'Under'}</div><div class="ks">${tpct}% time used</div></div>
      <div class="kpi"><div class="kl">Recent CPC</div><div class="kv">${fmt$(d.recentCpc)}</div><div class="ks">vs cap ${fmt$(d.bidCapOverride||0)}</div></div>
    </div>
    <div style="font-size:10px;color:#6b7280;margin-bottom:3px">Fulfillment ${pct}%</div>
    <div class="prog"><div class="pf" style="width:${Math.min(pct,100)}%;background:${pct>=90?'#16a34a':pct>=70?'#d97706':'#dc2626'}"></div></div>
    <div style="font-size:10px;color:#6b7280;margin-top:6px;margin-bottom:3px">Time elapsed ${tpct}%</div>
    <div class="prog"><div class="pf" style="width:${Math.min(tpct,100)}%;background:#9ca3af"></div></div>
  </div>

  <div class="section">
    <h2>QA Results Summary</h2>
    <div class="qa-summ">
      <div class="qs pass"><div class="qn pass">${pass}</div><div class="ql">Passed</div></div>
      <div class="qs fail"><div class="qn fail">${fails}</div><div class="ql">Failed</div></div>
      <div class="qs warn"><div class="qn warn">${warns}</div><div class="ql">Warnings</div></div>
      <div class="qs info"><div class="qn info">${qa.filter(r=>r.status==='info').length}</div><div class="ql">Info</div></div>
    </div>
    ${Object.entries(groups).map(([g,items])=>`
      <div class="qgroup">
        <div class="qgh">${items.filter(i=>i.status==='fail').length>0?'🔴':items.filter(i=>i.status==='warn').length>0?'🟡':'🟢'} ${g}</div>
        ${items.map(i=>`<div class="qi"><div class="qico ${i.status}">${i.status==='pass'?'✓':i.status==='fail'?'✗':i.status==='warn'?'!':'i'}</div><div><div class="qn2">${i.name}</div>${i.detail?`<div class="qd">${i.detail}</div>`:''} ${i.fix?`<div class="qf">→ ${i.fix}</div>`:''}</div></div>`).join('')}
      </div>`).join('')}
  </div>
  
  <div style="margin-top:24px;padding-top:12px;border-top:1px solid #e5e7eb;font-size:10px;color:#9ca3af">
    Generated by MatchCraft QA · Your Digital Agents · ${new Date().toISOString()}
  </div>
  <script>window.onload=()=>{window.print();}</script>
  </body></html>`;

  const blob = new Blob([html], {type:'text/html'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'campaign_'+S.active+'_QA_'+new Date().toISOString().slice(0,10)+'.html';
  a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 2000);
  showToast('PDF report downloaded — open the .html file and print/save as PDF', 'info', 4000);
}

// ─── TOAST NOTIFICATION ───────────────────────────────────────────────────────
function showToast(msg, type='info', duration=3000) {
  let toast = ge('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.style.cssText = 'position:fixed;bottom:16px;left:50%;transform:translateX(-50%);padding:10px 16px;border-radius:8px;font-size:12px;font-weight:500;z-index:99999;max-width:380px;text-align:center;transition:opacity .3s;box-shadow:0 4px 16px rgba(0,0,0,.4)';
    document.body.appendChild(toast);
  }
  const colors = {info:'background:#1e3a8a;color:#93c5fd;border:1px solid #3b82f6',warn:'background:#78350f;color:#fcd34d;border:1px solid #f59e0b',ok:'background:#14532d;color:#6ee7b7;border:1px solid #10b981'};
  toast.style.cssText += ';'+( colors[type]||colors.info);
  toast.textContent = msg;
  toast.style.opacity = '1';
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(()=>{toast.style.opacity='0';},duration);
}

function exportCSV() {
  const acct=S.accounts.find(a=>a.id===S.active); if(!acct||!acct.data)return;
  const d=acct.data.advertiser&&acct.data.advertiser.result; if(!d)return;
  const rows = buildExportRows(acct, d);
  const csv=rows.map(r=>(Array.isArray(r)?r:[r,'']).map(v=>'"'+String(v||'').replace(/"/g,'""')+'"').join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);
  a.download='campaign_'+S.active+'_QA_'+new Date().toISOString().slice(0,10)+'.csv';a.click();
}

function exportJSON() {
  const acct=S.accounts.find(a=>a.id===S.active); if(!acct||!acct.data)return;
  const blob=new Blob([JSON.stringify(acct.data,null,2)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);
  a.download='campaign_'+S.active+'_'+new Date().toISOString().slice(0,10)+'.json';a.click();
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const fmt$=n=>n==null?'—':'$'+parseFloat(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const fmtD=d=>{if(!d)return'—';if(d instanceof Date)return d.toLocaleDateString();const s=String(d);return s.length===8?s.slice(0,4)+'-'+s.slice(4,6)+'-'+s.slice(6):s;};
const fmtPh=p=>{if(!p)return'—';const s=String(p).replace(/\D/g,'');return s.length===10?'('+s.slice(0,3)+') '+s.slice(3,6)+'-'+s.slice(6):s.length===11?'+'+s[0]+' ('+s.slice(1,4)+') '+s.slice(4,7)+'-'+s.slice(7):p;};
const esc=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const ir=(l,v)=>`<div class="ir"><span class="il">${l}</span><span class="iv">${v||'—'}</span></div>`;
const noRows=c=>`<tr><td colspan="${c}" style="text-align:center;color:var(--muted);padding:14px">No data</td></tr>`;
const sv=(id,html)=>{const el=ge(id);if(el)el.innerHTML=html;};
