// content.js — injected into advertiserreports.com pages
// Listens for fetch requests from the extension popup and executes them
// in the page context (same origin = no CORS)

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'CONTENT_FETCH') {
    const url = msg.url;
    fetch(url, {
      credentials: 'include',
      headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }
    })
      .then(r => r.ok ? r.json() : Promise.reject('HTTP ' + r.status))
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  // Auto-detect merchant ID from current page URL/hash
  if (msg.type === 'GET_PAGE_CONTEXT') {
    const url = window.location.href;
    const hash = window.location.hash;
    let merchantId = null;

    const hashMatch = hash.match(/order[:/](\d+)/);
    const urlMatch = url.match(/merchantId=(\d+)/);
    const pathMatch = url.match(/\/(\d{6,9})\b/);

    merchantId = (hashMatch || urlMatch || pathMatch || [])[1] || null;
    sendResponse({ url, merchantId, origin: window.location.origin });
    return true;
  }
});
