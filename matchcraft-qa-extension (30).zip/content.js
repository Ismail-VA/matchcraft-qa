// MatchCraft QA - Content Script
// Intercepts ALL XHR/fetch calls and captures full request details

(function() {
  const captured = {};
  
  // Intercept XHR
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  
  XMLHttpRequest.prototype.open = function(method, url) {
    this._mcUrl = url;
    this._mcMethod = method;
    return origOpen.apply(this, arguments);
  };
  
  XMLHttpRequest.prototype.send = function(body) {
    const url = this._mcUrl || '';
    if (url.includes('advertiserreports.com') && url.includes('/rip/')) {
      const epName = url.split('/').pop().split('?')[0];
      const path = url.replace(/https?:\/\/[^/]+/, '').split('?')[0];
      
      let parsedBody = {};
      try { parsedBody = JSON.parse(body || '{}'); } catch(e) {}
      
      const entry = {
        name: epName,
        path: path,
        url: url.split('?')[0],
        method: this._mcMethod,
        bodyId: parsedBody?.data?.id || parsedBody?.id || null,
        ts: Date.now()
      };
      
      captured[epName + '_' + (entry.bodyId||'')] = entry;
      chrome.runtime.sendMessage({type:'CAPTURED_EP', entry}).catch(()=>{});
      
      // Also capture response
      const origOnLoad = this.onload;
      this.addEventListener('load', function() {
        try {
          const resp = JSON.parse(this.responseText || '{}');
          const result = resp.result;
          const count = Array.isArray(result) ? result.length : 
                        (result && typeof result === 'object' ? Object.keys(result).length : 0);
          entry.responseKb = (this.responseText.length / 1024).toFixed(1);
          entry.itemCount = count;
          captured[epName + '_' + (entry.bodyId||'')] = entry;
          chrome.runtime.sendMessage({type:'CAPTURED_EP', entry}).catch(()=>{});
        } catch(e) {}
      });
    }
    return origSend.apply(this, arguments);
  };

  // Listen for popup requests
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'GET_CAPTURED') {
      sendResponse({captured: Object.values(captured)});
      return true;
    }
  });
})();
