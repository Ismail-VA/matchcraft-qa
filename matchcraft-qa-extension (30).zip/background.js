// background.js v3 — logs all responses for debugging

const capturedEPs = {};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'CAPTURED_EP') {
    const e = msg.entry;
    capturedEPs[e.name + '_' + (e.bodyId||'')] = e;
    return;
  }
  if (msg.type === 'GET_CAPTURED') {
    sendResponse({captured: Object.values(capturedEPs)});
    return true;
  }
  if (msg.type === 'API_FETCH') {
    doFetch(msg.url, msg.postBody || null)
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (msg.type === 'GET_SESSION_INFO') {
    getSessionInfo(msg.baseUrl)
      .then(info => sendResponse({ ok: true, info }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});

async function doFetch(url, postBody) {
  const opts = {
    credentials: 'include',
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'Accept': 'application/json, text/javascript, */*; q=0.01',
    }
  };

  if (postBody) {
    opts.method = 'POST';
    opts.headers['Content-Type'] = 'application/json; charset=UTF-8';
    opts.body = JSON.stringify(postBody);
  } else {
    opts.method = 'GET';
  }

  const resp = await fetch(url, opts);
  
  // Log every response for debugging
  const endpoint = url.split('/').pop().split('?')[0];
  const path = url.replace(/https?:\/\/[^/]+/, '').replace('/' + endpoint, '');
  
  if (!resp.ok) {
    console.log(`[MC QA BG] ${resp.status} ${endpoint} @ ${path}`);
    throw new Error('HTTP ' + resp.status);
  }

  const text = await resp.text();
  if (!text || !text.trim()) {
    console.log(`[MC QA BG] EMPTY ${endpoint} @ ${path}`);
    throw new Error('Empty response');
  }

  const data = JSON.parse(text);
  const resultKeys = data && typeof data === 'object' ? Object.keys(data) : [];
  console.log(`[MC QA BG] 200 ${endpoint} @ ${path} | keys: ${resultKeys.join(',')} | result: ${JSON.stringify(data.result || data).slice(0,60)}`);
  
  return data;
}

async function getSessionInfo(baseUrl) {
  const paths = [
    { url: baseUrl + '/rip/common/json/getSessionState', method: 'POST_JSON' },
    { url: baseUrl + '/rip/json/getSessionState', method: 'GET' },
    { url: baseUrl + '/rip/manage/json/getSessionState', method: 'POST_JSON' },
  ];
  
  for (const p of paths) {
    try {
      const opts = {
        credentials: 'include',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }
      };
      if (p.method === 'POST_JSON') {
        opts.method = 'POST';
        opts.headers['Content-Type'] = 'application/json';
        opts.body = '{}';
      } else {
        opts.method = 'GET';
      }
      const r = await fetch(p.url, opts);
      if (!r.ok) continue;
      const d = await r.json();
      if (!d) continue;
      return { data: d, path: p.url, method: p.method };
    } catch(e) {}
  }
  throw new Error('Could not reach session endpoint');
}
